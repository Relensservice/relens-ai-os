ReLens ValueVis Lens Reference Banners

Upload the contents of assets/banners/ to the GitHub repository at:
assets/banners/

The website slider is already configured to load slide1.webp through slide6.webp.
These are reference images supplied by the ReLens user; final lens selection should be verified against the prescription, design and availability.
